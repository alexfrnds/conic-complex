# CComplex
This module accompanies : _INSERT REF ARXIV_ 

## Summary
Computes the gamma-linear projected barcode of conic complex with (potentially) the use of the projected barcode template.

## Requirement
The following module is required:
- [phat python bindings](https://github.com/xoltar/phat)

Bug fix : if 'pybind11' is not recognized just reinstall setuptools from pip.

## Requirements (examples)
The repository contains notebooks to generate examples using the python binding of [2pac](https://gitlab.com/flenzen/2pac).

